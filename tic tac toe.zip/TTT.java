import java.awt.*;  
import javax.swing.*;
import java.awt.event.*;    
public class TTT extends Frame implements ActionListener{  
static int p=0;
static String symbol="0";
static String symbol2="";
static String temp1=symbol;
static String pp="";
Button bp1,bp2,bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,bt10,bt11,bt12;
TextField F1,F2; 
    TTT(){  
	
    F1=new TextField("");
    F2=new TextField(""); 	
	bp1=new Button("player 1"); 
	bp2=new Button("player 2"); 
    bt1=new Button(""); 
    bt2=new Button(""); 
    bt3=new Button(""); 
    bt4=new Button("");
    bt5=new Button(""); 
    bt6=new Button(""); 
    bt7=new Button(""); 
    bt8=new Button(""); 
    bt9=new Button(""); 
    bt10=new Button("Swap symbol"); 
    bt11=new Button("play again");
	bt12=new Button("symbol info");
	
	
	F1.setFont(new Font("SansSerif", Font.BOLD, 20));
	F2.setFont(new Font("SansSerif", Font.BOLD, 20));
	bt1.setFont(new Font("Arial", Font.PLAIN, 40));
	bt2.setFont(new Font("Arial", Font.PLAIN, 40));
	bt3.setFont(new Font("Arial", Font.PLAIN, 40));
	bt4.setFont(new Font("Arial", Font.PLAIN, 40));
	bt5.setFont(new Font("Arial", Font.PLAIN, 40));
	bt6.setFont(new Font("Arial", Font.PLAIN, 40));
	bt7.setFont(new Font("Arial", Font.PLAIN, 40));
	bt8.setFont(new Font("Arial", Font.PLAIN, 40));
	bt9.setFont(new Font("Arial", Font.PLAIN, 40));
	
	
	
	
	
F1.setBounds(100,70,80,30);
F2.setBounds(190,70,80,30);
bp1.setBounds(100,50,80,20); 
bp2.setBounds(190,50,80,20); 
bt1.setBounds(100,150,60,60);    
bt2.setBounds(160,150,60,60);  
bt3.setBounds(220,150,60,60);  
bt4.setBounds(100,210,60,60);  
bt5.setBounds(160,210,60,60);  
bt6.setBounds(220,210,60,60);  
bt7.setBounds(100,270,60,60);  
bt8.setBounds(160,270,60,60);  
bt9.setBounds(220,270,60,60);  
bt10.setBounds(150,380,100,40);
	 bt11.setBounds(270,380,100,40);
	 bt12.setBounds(50,380,80,40);
	
	
	 add(bp1);
	add(bp2);
	add(bt1);
	add(bt2);
	add(bt3);
	add(bt4);
	add(bt5);
	add(bt6);
	add(bt7);
	add(bt8);
	add(bt9);  
	add(bt10);
	add(bt11);
	add(bt12);
	
	
	
	
	F1.addActionListener(this);
	F1.addActionListener(this);
    bt1.addActionListener(this);  
    bt2.addActionListener(this);  
    bt3.addActionListener(this);  
    bt4.addActionListener(this);  
    bt5.addActionListener(this);  
    bt6.addActionListener(this);  
    bt7.addActionListener(this);  
    bt8.addActionListener(this);  
    bt9.addActionListener(this);  
    bt10.addActionListener(this);
	bt11.addActionListener(this);
	bt12.addActionListener(this);
	
	
	
    setSize(480,480);  
    setLayout(null);  
    setVisible(true);  
	setBackground(Color.green);  	
	JOptionPane.showMessageDialog(this,"player 1 will have symbol \"0\" and player 2 will have \"x\". \n\n                   please enter your names");

    add(F1);
    add(F2);
}  
public void actionPerformed(ActionEvent e){
	if(e.getSource()==bt12){
	JOptionPane.showMessageDialog(this,"* symbols may keep on changing for each game\n* to swap symbols for each  game click on swap symbols");
	}
	
	 if(e.getSource()==bt11)
			{   
		       if(symbol.equals("x"))
				   symbol2="0";
			   else if(symbol.equals("0"))
				   symbol2="x";
				p=0;
				bt1.setLabel("");
				bt2.setLabel("");
				bt3.setLabel("");
				bt4.setLabel("");
				bt5.setLabel("");
				bt6.setLabel("");
				bt7.setLabel("");
				bt8.setLabel("");
				bt9.setLabel("");
				JOptionPane.showMessageDialog(this,"now player 1 symbol: "+symbol+"\n       player 2 symbol: "+symbol2);
				
			}
	 
	 		
			if(e.getSource()==bt10)
			{
				if(bt1.getLabel().equals("")&&bt2.getLabel().equals("")&&bt3.getLabel().equals("")
				&&bt4.getLabel().equals("")&&bt5.getLabel().equals("")&&bt6.getLabel().equals("")
			    &&bt7.getLabel().equals("")&&bt8.getLabel().equals("")&&bt9.getLabel().equals(""))
				{
					if(symbol.equals("x"))
						symbol="0";
					else if(symbol.equals("0"))
						symbol="x";
					JOptionPane.showMessageDialog(this,"symbols changed");
				}
			}
			



    if(e.getSource()==bt1){  
        if(bt1.getLabel().equals("")){   
            bt1.setLabel(symbol);  
			p++;
        }  
    }  
    if(e.getSource()==bt2){    
        if(bt2.getLabel().equals("")){    
            bt2.setLabel(symbol);
			p++;			
	}  }
      
	

if(e.getSource()==bt3){    
        if(bt3.getLabel().equals("")){    
            bt3.setLabel(symbol);  
	          p++;
	}  }



    if(e.getSource()==bt4){    
        if(bt4.getLabel().equals("")){    
            bt4.setLabel(symbol);
          p++;			
	}  }
        
		
		
		
    if(e.getSource()==bt5){   
        if(bt5.getLabel().equals("")){    
            bt5.setLabel(symbol);
       p++;			
	}} 
        
		
		
		
    if(e.getSource()==bt6){    
        if(bt6.getLabel().equals("")){    
            bt6.setLabel(symbol);
           p++;			
	}  }
      
	  
	  
	  
    if(e.getSource()==bt7){    
        if(bt7.getLabel().equals("")){  
            bt7.setLabel(symbol);  
	      p++;
	}  }
        
		
		
    if(e.getSource()==bt8){    
        if(bt8.getLabel().equals("")){    
            bt8.setLabel(symbol);
          p++;			
	}  }  



    if(e.getSource()==bt9){    
        if(bt9.getLabel().equals("")){    
            bt9.setLabel(symbol);
        p++;			
	}  }
   	   

if((e.getSource()==bt1)||(e.getSource()==bt2)||(e.getSource()==bt3)||(e.getSource()==bt4)||(
e.getSource()==bt5)||(e.getSource()==bt6)||(e.getSource()==bt7)||(e.getSource()==bt8)||(
e.getSource()==bt9)){			
if(symbol.equals("x"))
symbol="0";
else if(symbol.equals("0"))
symbol="x";
}


/*if((e.getSource()==bt1&&bt1.getLabel().equals(""))||(e.getSource()==bt2&&bt2.getLabel().equals(""))||(e.getSource()==bt3&&bt3.getLabel().equals(""))||
(e.getSource()==bt4&&bt4.getLabel().equals(""))||(e.getSource()==bt5&&bt5.getLabel().equals(""))||(e.getSource()==bt6&&bt6.getLabel().equals(""))
||(e.getSource()==bt7&&bt7.getLabel().equals(""))||(e.getSource()==bt8&&bt8.getLabel().equals(""))||(e.getSource()==bt9&&bt9.getLabel().equals(""))){			
if(symbol.equals("x"))
symbol="0";
else if(symbol.equals("0"))
symbol="x";
}*/					
   

   
//resulting code  starts
    if((bt1.getLabel().equals("x")||bt1.getLabel().equals("0"))&&
	((bt1.getLabel().equals(bt2.getLabel())&&bt2.getLabel().equals(bt3.getLabel()))||
	(bt1.getLabel().equals(bt4.getLabel())&&bt4.getLabel().equals(bt7.getLabel()))||
	(bt1.getLabel().equals(bt5.getLabel())&&bt5.getLabel().equals(bt9.getLabel())))){
        if(p%2!=0)
          pp=F1.getText();
        else
         pp=F2.getText();			
            JOptionPane.showMessageDialog(this,"Congrats! You won "+pp);			
    }
	
	
	else if((bt9.getLabel().equals("x")||bt9.getLabel().equals("0"))&&(
	(bt9.getLabel().equals(bt6.getLabel())&&bt6.getLabel().equals(bt3.getLabel()))||
	(bt9.getLabel().equals(bt8.getLabel())&&bt8.getLabel().equals(bt7.getLabel())))){     
            if(p%2!=0)
          pp=F1.getText();
        else
         pp=F2.getText();
			JOptionPane.showMessageDialog(this,"Congrats! You won "+pp);			
    }
	
	
	else if((bt2.getLabel().equals("x")||bt2.getLabel().equals("0"))&&(
	(bt2.getLabel().equals(bt5.getLabel())&&bt5.getLabel().equals(bt8.getLabel())))){     
            if(p%2!=0)
          pp=F1.getText();
        else
         pp=F2.getText();
			JOptionPane.showMessageDialog(this,"Congrats! You won "+pp);			
    }
	
	
	else if((bt4.getLabel().equals("x")||bt4.getLabel().equals("0"))&&(
	(bt4.getLabel().equals(bt5.getLabel())&&bt5.getLabel().equals(bt6.getLabel())))){     
            if(p%2!=0)
          pp=F1.getText();
        else
         pp=F2.getText();
			JOptionPane.showMessageDialog(this,"Congrats! You won "+pp);			
    }
	
	else if((bt7.getLabel().equals("x")||bt7.getLabel().equals("0"))&&(
	(bt7.getLabel().equals(bt5.getLabel())&&bt5.getLabel().equals(bt3.getLabel())))){
	if(p%2!=0)
          pp=F1.getText();
        else
         pp=F2.getText();
	JOptionPane.showMessageDialog(this,"congrats you won "+pp);
	}
	//resulting code ends
	
}  
public static void main(String []args) {  
    new TTT();  
}   
} 